-- Trigger types regeneration
SELECT 1;